require_relative "lib/game"

player1, player2 = Game.setup
game = Game.new(player1, player2)
game.start