require_relative "board"
require_relative "player"
require_relative "color"
require_relative "piece"
require_relative "piece_unicode"
require_relative "pieces/pawn"
require_relative "pieces/rook"
require_relative "pieces/knight"
require_relative "pieces/bishop"
require_relative "pieces/queen"
require_relative "pieces/king"
require_relative "help"

class Game
  def initialize(player1, player2)
    @player1 = player1
    @player2 = player2
    @board = Board.new
    @turn = player1.color == :White ? player1 : player2
    @set_ending = nil
  end

  def self.new_game(name1, color1, name2, color2)
    player1 = Player.new(name1, color1)
    player2 = Player.new(name2, color2)
    game = Game.new(player1, player2)
    game.start
  end

  def start
    print "Start!\n"
    while !gameover?
      @board.draw
      if @board.check?(@turn.color).first
        puts "Check!"
      end
      play_turn
      switch_turn unless gameover?
    end
    @board.draw
    game_end
  end

  def switch_turn
    @turn = (@turn == @player1) ? @player2 : @player1
  end

  def gameover?
    if checkmate?
      @set_ending = 1
      return true
    elsif stalemate?
      @set_ending = 2
      return true
    elsif draw?
      return true
    elsif @set_ending == 3
      return true
    else
      return false
    end
  end

  def game_end
    if @set_ending == 1
      opp_color = @turn.color == :White ? :Black : :White
      
      puts "#{opp_color} has won by checkmate."
    elsif @set_ending == 2
      puts "#{@turn.color} draws by a stalemate."
    elsif @set_ending == 3
      puts "#{@turn.color} resigns. Defeat due to surrender."
    else
      puts "Draw by a lack of enough material."
    end
  end

  def checkmate?
    is_check, attackers = @board.check?(@turn.color)
    return false unless is_check

    opp_color = @turn.color == :White ? :Black : :White
    king_pos = @board.where_king(@turn.color)
    directions = 
    [
      [1, 0], [-1, 0], [0, 1], [0, -1],
      [1, 1], [1, -1], [-1, -1], [-1, 1]
    ]

    directions.each do |dr, dc|
      r = king_pos.row + dr
      c = king_pos.col + dc

      next unless r.between?(1, 8) && c.between?(1, 8)
      to = Position.new(r, c)
      if @board.squares[king_pos.row][king_pos.col].piece&.can_move?(to, @board)
        return false
      end
    end

    return true if attackers.size > 1
    attacker = attackers.first
    8.times do |i|
      8.times do |j|
        piece = @board.squares[i+1][j+1].piece
        next unless piece && piece.color == @turn.color
        if piece.can_move?(attacker.pos, @board)
          return false
        end
      end
    end

    if attacker.is_a?(Knight)
    return true

    else
      path = @board.squares_between(attacker.pos, king_pos)
      path.each do |block_pos|
        8.times do |i|
          8.times do |j|
            piece = @board.squares[i+1][j+1].piece
            next unless piece && piece.color == @turn.color
            if piece && piece.can_move?(block_pos, @board)
              return false
            end
          end
        end
      end
    end

    return true
  end

  def stalemate?

    return false if @board.check?(@turn.color).first

    8.times do |i|
      8.times do |j|
        piece = @board.squares[i+1][j+1].piece
        next unless piece && piece.color == @turn.color

        self.all_moves.each do |to|
        next unless piece.can_move?(to, @board)

            from = piece.pos
            target_piece = @board.squares[to.row][to.col].piece
            @board.squares[from.row][from.col].piece = nil
            @board.squares[to.row][to.col].piece = piece
            piece.pos = to
            in_check, _ = @board.check?(@turn.color)

            @board.squares[from.row][from.col].piece = piece
            @board.squares[to.row][to.col].piece = target_piece
            piece.pos = from
            return false unless in_check
        end
      end
    end
  end

  def all_moves
    move_list = []

    8.times do |i|
      8.times do |j|
        move_list << Position.new(i+1, j+1)
      end
    end
    return move_list
  end

  def draw?
    pieces = []
    8.times do |i|
      8.times do |j|
        piece = @board.squares[i+1][j+1].piece
        pieces << piece if piece
      end
    end

    return true if pieces.all? { |p| p.is_a?(King) }

    if pieces.size == 3
      return true if pieces.count { |p| p.is_a?(King) } == 2 &&
                     pieces.any? { |p| p.is_a?(Bishop) || p.is_a?(Knight) }
    end

    if pieces.size == 4
      bishops = pieces.select { |p| p.is_a?(Bishop) }
      if bishops.size == 2
        b1 = bishops[0]
        b2 = bishops[1]
        same_color = (b1.pos.row + b1.pos.col) % 2 == (b2.pos.row + b2.pos.col) % 2
        return true if same_color
      end
    end

    return false
  end

  def play_turn
    puts "#{@turn.color} to move...\n(for help press [h])"
    input = gets.strip
    if input == "resign"
      @set_ending = 3
      return
    elsif input == "h"
      Help.show
    elsif input == "q"
      exit
    end
    puts
    @turn.make_move(input, @board)
  end

  def self.setup
    puts "Select name for the first player: "
    name1 = gets.strip
    color1 = nil
    until color1 == 'W' || color1 == 'B'
      puts "Choose color (White, Black) from [W, B]"
      color1 = gets.strip
      puts "Invalid color. Enter correct color." unless color1 == 'W' || color1 == 'B'
    end
    puts "Select name for the second player: "
    name2 = gets.strip
    color1 == 'W' ? color1 = :White : color1 = :Black
    color1 == :White ? color2 = :Black : color2 = :White
    player1 = Player.new(name1, color1)
    player2 = Player.new(name2, color2)
    return [player1, player2]
  end

end
