module Color
  WHITE = :White
  BLACK = :Black

  def self.valid?(color)
    [WHITE, BLACK].include?(color)
  end
end
