PIECE_UNICODE = {
  Black: {
    'K' => '♔',
    'Q' => '♕',
    'R' => '♖',
    'B' => '♗',
    'N' => '♘',
    'P' => '♙'
  },
  White: {
    'K' => '♚',
    'Q' => '♛',
    'R' => '♜',
    'B' => '♝',
    'N' => '♞',
    'P' => '♟'
  }
}

def symbol_for(color, piece)
  return ' ' if piece.nil?
  
  symbol = 
  case piece
    when King then 'K'
    when Queen then 'Q'
    when Rook then 'R'
    when Bishop then 'B'
    when Knight then 'N'
    when Pawn then 'P'
    else nil
    end

  PIECE_UNICODE[color][symbol]
end
