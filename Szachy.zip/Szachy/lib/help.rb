require 'io/console'

class Help
  def self.show
    puts "\n-------MOVE TYPE LIST-------\n
    1) Pawn moves:
    from: [col][row] to: [col][row],    example: e2e4
    2) Piece moves:
    piece: [Q,N,B,R,K] from: [col][row] to: [col][row],    example: Ng1f3
    3) En passant:
    from: [col][row] to: [col][row] sufix: [ep],    example: e5d6ep
    4) Castle:
    short castle: [O-O], long castle: [O-O-O]
    5) Special:
    [resign] - type to resign
    [h] - help
    [q] - quit"
    puts "\nPress any key to continue..."
    STDIN.getch
  end
end