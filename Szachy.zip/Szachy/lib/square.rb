require_relative "piece"

class Square
  attr_accessor :piece
  def initialize(piece)
    @piece = piece
  end

  def free?
    @piece == nil
  end

  def capture?
    @piece != nil
  end
end