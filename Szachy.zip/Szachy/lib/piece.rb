require_relative "color"
require_relative "position"

class Piece
  attr_accessor :pos 
  attr_reader :color
  def initialize(pos, color)
    @pos = pos
    @color = color 
  end

  def can_move?(to, board)
    raise NotImplementedError, "#{self.class} must implement can_move?"
  end
end