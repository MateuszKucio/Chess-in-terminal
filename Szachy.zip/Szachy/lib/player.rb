require_relative "color"
require_relative "piece_unicode"
require_relative "pieces/pawn"

class Player
  attr_reader :color, :name
  def initialize(name, color)
    @name = name
    @color = color
  end

  def make_move(input, board)
    case input

    when "O-O"
      pos = board.where_king(@color)
      piece = board.get_piece(pos)
      if piece.short_castle(@color, board)
        puts "#{@color} makes short castle."
      else
        puts "Illegal move for #{symbol_for(@color, piece)}. Try again..."
        new_input = gets.strip
        make_move(new_input, board)
      end

    when "O-O-O"
      pos = board.where_king(@color)
      piece = board.get_piece(pos)
      if piece.long_castle(@color, board)
        puts "#{@color} makes long castle."
      else
        puts "Illegal move for #{symbol_for(@color, piece)}. Try again..."
        new_input = gets.strip
        make_move(new_input, board)
      end

    when /\A[K,Q,B,R,N]?[a-h][1-8][a-h][1-8][e]?[p]?\z/
      if input.length == 5
        from = Position.new(input[2].to_i, input[1].ord - 'a'.ord + 1)
        to = Position.new(input[4].to_i, input[3].ord - 'a'.ord + 1)
        piece = board.get_piece(from)
        if piece && piece.can_move?(to, board) && piece.color == @color
          if !board.move(from, to)
            new_input = gets.strip
            make_move(new_input, board)
          else
            puts "#{@color} moved #{symbol_for(@color, piece)}  from #{input[1..2]} to #{input[3..4]}."
          end
        else
          if piece == nil || piece.color != @color
            puts "Illegal move. Try again..."
          else
            puts "Illegal move for #{symbol_for(@color, piece)}. Try again..."
          end
          new_input = gets.strip
          make_move(new_input, board)
        end
          
      elsif input[4..5] == "ep"
        from = Position.new(input[1].to_i, input[0].ord - 'a'.ord + 1)
        to = Position.new(input[3].to_i, input[2].ord - 'a'.ord + 1)
        piece = board.get_piece(from)
        if piece && piece.can_move?(to, board) && piece.color == @color
          if piece.en_passant(to, board.last_move, board)
            if !board.move(from, to)
              new_input = gets.strip
              make_move(new_input, board)
            else 
              puts "#{@color} makes #{symbol_for(@color, piece)}  en passant from #{input[0..1]} to #{input[2..3]}."
            end
          end
        else
          if piece == nil || piece.color != @color
            puts "Illegal move. Try again..."
          else
            puts "Illegal move for #{symbol_for(@color, piece)}. Try again..."
          end
          new_input = gets.strip
          make_move(new_input, board)
        end
      
      elsif input.length == 4
        from = Position.new(input[1].to_i, input[0].ord - 'a'.ord + 1)
        to = Position.new(input[3].to_i, input[2].ord - 'a'.ord + 1)
        piece = board.get_piece(from)
        if piece && piece.can_move?(to, board) && piece.color == @color
          if !board.move(from, to)
            new_input = gets.strip
            make_move(new_input, board)
          else
            puts "#{@color} moved #{symbol_for(@color, piece)}  from #{input[0..1]} to #{input[2..3]}."
            piece.promotion(to, board)
          end
        else
          if piece == nil || piece.color != @color
            puts "Illegal move. Try again..."
          else
            puts "Illegal move for #{symbol_for(@color, piece)}. Try again..."
          end
          new_input = gets.strip
          make_move(new_input, board)
        end

      else
        puts "Invalid move format. Try again..."
        new_input = gets.strip
        make_move(new_input, board)
      end

    else
        puts "Invalid move format. Try again..."
        new_input = gets.strip
        make_move(new_input, board)
    end
  end
end