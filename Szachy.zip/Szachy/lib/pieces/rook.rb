require_relative "../piece"
require_relative "../color"
require_relative "../piece_unicode"
require_relative "../square"
require_relative "../position"

class Rook < Piece
  def can_move?(to, board)

    square = board.squares[to.row][to.col]
    if !square.free? && square.piece.color == @color
      return false
    end

    from = @pos

    if from.row == to.row && from.col != to.col
      row = from.row
      if from.col < to.col
        (from.col + 1...to.col).each do |c|
          return false unless board.squares[row][c].free?
        end
      else 
        (to.col + 1...from.col).each do |c|
          return false unless board.squares[row][c].free?
        end
      end
      return true

    elsif from.col == to.col && from.row != to.row
      col = from.col
      if from.row < to.row
        (from.row + 1...to.row).each do |r|
          return false unless board.squares[r][col].free?
        end
      else 
        (to.row + 1...from.row).each do |r|
          return false unless board.squares[r][col].free?
        end
      end
      return true
      
    else
      return false
    end
  end

end