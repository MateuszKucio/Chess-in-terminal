require_relative "../piece"
require_relative "../color"
require_relative "../piece_unicode"
require_relative "../square"
require_relative "../position"

class King < Piece
  
  def illegal_position(pos, board)
    opp_color = @color == :White ? :Black : :White
    8.times do |i|
      8.times do |j|
        piece = board.squares[i+1][j+1].piece
        next unless piece && piece.color == opp_color
        if piece.is_a?(King)
          return true if (piece.pos.row - pos.row).abs <= 1 && (piece.pos.col - pos.col).abs <= 1
        else
          return true if piece.can_move?(pos, board)
        end
      end
    end
    return false
  end

  def can_move?(to, board)
    square = board.squares[to.row][to.col]
    return false if square.piece&.color == @color

    original_pos = @pos
    captured_piece = board.get_piece(to)
    board.squares[original_pos.row][original_pos.col].piece = nil
    board.squares[to.row][to.col].piece = self
    @pos = to
    in_check, _ = board.check?(@color)

    board.squares[original_pos.row][original_pos.col].piece = self
    board.squares[to.row][to.col].piece = captured_piece
    @pos = original_pos
    return false if in_check

    dr = (to.row - original_pos.row).abs
    dc = (to.col - original_pos.col).abs
    return dr <= 1 && dc <= 1
  end

  def short_castle(color, board)
    possible = true
    king_row = color == :White ? 1 : 8
    king_col = 5
    rook_col = 8
    king_col_to = 7
    rook_col_to = 6
    move_list = board.track_moves

    king_moved = move_list.any? { |from, to, piece| piece.is_a?(King) && piece.color == color && from.row == king_row && from.col == king_col }
    rook_moved = move_list.any? { |from, to, piece| piece.is_a?(Rook) && piece.color == color && from.row == king_row && from.col == rook_col }
    possible = false if king_moved || rook_moved

    (king_col+1...rook_col).each do |col|
      possible = false unless board.squares[king_row][col].free?
    end

    [5, 6, 7].each do |col|
      pos = Position.new(king_row, col)
      possible = false if board.square_attacked?(pos, color == :White ? :Black : :White)
    end

    if possible
      king = board.squares[king_row][king_col].piece
      rook = board.squares[king_row][rook_col].piece

      board.squares[king_row][king_col].piece = nil
      board.squares[king_row][king_col_to].piece = king
      king.pos = Position.new(king_row, king_col_to)

      board.squares[king_row][rook_col].piece = nil
      board.squares[king_row][rook_col_to].piece = rook
      rook.pos = Position.new(king_row, rook_col_to)
    end
    return possible
  end

  def long_castle(color, board)
    possible = true
    king_row = color == :White ? 1 : 8
    king_col = 5
    rook_col = 1
    king_col_to = 3
    rook_col_to = 4
    move_list = board.track_moves

    king_moved = move_list.any? { |from, to, piece| piece.is_a?(King) && piece.color == color && from.row == king_row && from.col == king_col }
    rook_moved = move_list.any? { |from, to, piece| piece.is_a?(Rook) && piece.color == color && from.row == king_row && from.col == rook_col }
    possible = false if king_moved || rook_moved

    (rook_col+1...king_col).each do |col|
      possible = false unless board.squares[king_row][col].free? 
    end

    [5, 4, 3].each do |col|
      pos = Position.new(king_row, col)
      possible = false if board.square_attacked?(pos, color == :White ? :Black : :White)
    end

    if possible
      king = board.squares[king_row][king_col].piece
      rook = board.squares[king_row][rook_col].piece

      board.squares[king_row][king_col].piece = nil
      board.squares[king_row][king_col_to].piece = king
      king.pos = Position.new(king_row, king_col_to)

      board.squares[king_row][rook_col].piece = nil
      board.squares[king_row][rook_col_to].piece = rook
      rook.pos = Position.new(king_row, rook_col_to)
    end
    return possible
  end

end