require_relative "../piece"
require_relative "../color"
require_relative "../piece_unicode"
require_relative "../square"
require_relative "../position"

class Bishop < Piece
  def can_move?(to, board)

    square = board.squares[to.row][to.col]
    if !square.free? && square.piece.color == @color
      return false
    end

    from = @pos

    if (from.col - to.col).abs == (from.row - to.row).abs
      row_step = to.row > from.row ? 1 : -1
      col_step = to.col > from.col ? 1 : -1
      r, c = from.row + row_step, from.col + col_step
      while r != to.row && c != to.col
        return false unless board.squares[r][c].free?
        r += row_step
        c += col_step
      end
      return true

    else
      return false
    end
  end
end
