require_relative "../piece"
require_relative "../color"
require_relative "../piece_unicode"
require_relative "../square"
require_relative "../position"

class Pawn < Piece
  def can_move?(to, board)

    square = board.squares[to.row][to.col]
    if !square.free? && square.piece.color == @color
      return false
    end

    from = @pos
    direction = (@color == :White) ? 1 : -1
    start_row = (@color == :White) ? 2 : 7

    if to.col == from.col && to.row == from.row + direction
      return true if board.squares[to.row][to.col].free?

    elsif to.col == from.col && from.row == start_row && to.row == from.row + 2 * direction
      middle_row = from.row + direction
      return true if board.squares[middle_row][to.col].free? && board.squares[to.row][to.col].free?

    elsif (to.col - from.col).abs == 1 && to.row == from.row + direction
      target_piece = board.squares[to.row][to.col].piece
      return true if target_piece && target_piece.color != @color
      
    else
      return false
    end
  end


  def promotion(pos, board)
    prom_row = @color == :White ? 8 : 1
    return unless pos.row == prom_row
    puts "Select piece you wish to be promoted from [Q, B, N, R].\n" 
    new_piece = gets.strip
    case new_piece
    when 'Q'
      board.squares[pos.row][pos.col].piece = Queen.new(pos, @color)
      puts "#{self.color} promotes to #{symbol_for(self.color, board.squares[pos.row][pos.col].piece)}.\n"
      return
    when 'B'
      board.squares[pos.row][pos.col].piece = Bishop.new(pos, @color)
      puts "#{self.color} promotes to #{symbol_for(self.color, board.squares[pos.row][pos.col].piece)}.\n"
      return
    when 'N'
      board.squares[pos.row][pos.col].piece = Knight.new(pos, @color)
      puts "#{self.color} promotes to #{symbol_for(self.color, board.squares[pos.row][pos.col].piece)}.\n"
      return
    when 'R'
      board.squares[pos.row][pos.col].piece = Rook.new(pos, @color)
      puts "#{self.color} promotes to #{symbol_for(self.color, board.squares[pos.row][pos.col].piece)}.\n"
      return
    end
    
    puts "Invalid choice, choose from [Q, B, N, R].\n"
    promotion(pos, board)
  end

  def en_passant(to, last_move, board)
    from_last, to_last, piece_last = last_move
    direction = (@color == :White) ? 2 : -2
    start_row = (@color == :White) ? 2 : 7

    if from_last.row == start_row &&
      to_last.row == from_last.row + direction &&
      piece_last.is_a?(Pawn)

      from = @pos
      direction2 = (@color == :White) ? 1 : -1
      start_row2 = (@color == :White) ? 5 : 4

      if start_row2 == from.row &&
        (from_last.col - from.col).abs == 1 &&
        to.col == from_last.col && to.row == from.row + direction2
        board.squares[to_last.row][to_last.col].piece = nil
        return true
      else
        return false
      end
    else
      return false
    end
  end
end
