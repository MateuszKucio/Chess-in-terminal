require_relative "../piece"
require_relative "../color"
require_relative "../piece_unicode"
require_relative "../square"
require_relative "../position"

class Knight < Piece
  def can_move?(to, board)

    square = board.squares[to.row][to.col]
    if !square.free? && square.piece.color == @color
      return false
    end

    from = @pos

    if to.row == from.row + 2 && to.col == from.col + 1 ||
       to.row == from.row + 2 && to.col == from.col - 1 ||
       to.row == from.row - 2 && to.col == from.col + 1 ||
       to.row == from.row - 2 && to.col == from.col - 1 ||
       to.row == from.row + 1 && to.col == from.col - 2 ||
       to.row == from.row - 1 && to.col == from.col - 2 ||
       to.row == from.row + 1 && to.col == from.col + 2 ||
       to.row == from.row - 1 && to.col == from.col + 2
      
      return true
    
    else
      return false
    end
  end
end