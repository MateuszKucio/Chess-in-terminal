require_relative "position"
require_relative "board"

class Move
  attr_reader :from, :to
  def initialize(from, to, board)
    @from = from
    @to = to
    @board = board
  end

  def capture?
    !board.squares[@to.row][@to.col].empty?
  end
end