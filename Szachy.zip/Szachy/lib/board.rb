require_relative "square"
require_relative "piece"
require_relative "piece_unicode"
require_relative "pieces/pawn"
require_relative "pieces/rook"
require_relative "pieces/knight"
require_relative "pieces/bishop"
require_relative "pieces/queen"
require_relative "pieces/king"
require_relative "move"

class Board
  attr_accessor :squares
  attr_reader :last_move, :track_moves

  def initialize
    @squares = Array.new(9) { Array.new(9) { Square.new(nil) } }
    @last_move = nil
    @track_moves = []
    8.times do |i|
      @squares[2][i + 1] = Square.new(Pawn.new(Position.new(2, i + 1), :White))
      @squares[7][i + 1] = Square.new(Pawn.new(Position.new(7, i + 1), :Black))
    end

    @squares[1][1] = Square.new(Rook.new(Position.new(1, 1), :White))
    @squares[1][2] = Square.new(Knight.new(Position.new(1, 2), :White))
    @squares[1][3] = Square.new(Bishop.new(Position.new(1, 3), :White))
    @squares[1][4] = Square.new(Queen.new(Position.new(1, 4), :White))
    @squares[1][5] = Square.new(King.new(Position.new(1, 5), :White))
    @squares[1][6] = Square.new(Bishop.new(Position.new(1, 6), :White))
    @squares[1][7] = Square.new(Knight.new(Position.new(1, 7), :White))
    @squares[1][8] = Square.new(Rook.new(Position.new(1, 8), :White))

    @squares[8][1] = Square.new(Rook.new(Position.new(8, 1), :Black))
    @squares[8][2] = Square.new(Knight.new(Position.new(8, 2), :Black))
    @squares[8][3] = Square.new(Bishop.new(Position.new(8, 3), :Black))
    @squares[8][4] = Square.new(Queen.new(Position.new(8, 4), :Black))
    @squares[8][5] = Square.new(King.new(Position.new(8, 5), :Black))
    @squares[8][6] = Square.new(Bishop.new(Position.new(8, 6), :Black))
    @squares[8][7] = Square.new(Knight.new(Position.new(8, 7), :Black))
    @squares[8][8] = Square.new(Rook.new(Position.new(8, 8), :Black))
  end

  def draw
    8.downto(1) do |row|
      print "#{row} |"
      1.upto(8) do |col|
        square = @squares[row][col]
        piece = square.piece
        print "#{symbol_for(piece&.color, piece)} "
      end
      puts
    end
    puts "   a b c d e f g h"
  end

  def move(from, to)
    moving_piece = get_piece(from)
    captured_piece = @squares[to.row][to.col].piece
    return puts "No piece at source." if moving_piece.nil?

    if moving_piece.can_move?(to, self)
      @squares[from.row][from.col].piece = nil
      if @squares[to.row][to.col].capture?
        puts "#{moving_piece.color} captures #{symbol_for(get_piece(to).color, get_piece(to))}."
      end 
      @squares[to.row][to.col].piece = moving_piece
      moving_piece.pos = to
      if check?(moving_piece.color).first
        @squares[from.row][from.col].piece = moving_piece
        @squares[to.row][to.col].piece = captured_piece
        moving_piece.pos = from
        puts "You must get out of check! Try again..."
        return false
      end

      @last_move = [from, to, moving_piece]
      @track_moves << @last_move
      return true
    else
        puts "Incorrect move."
        return false
    end
  end

  def check?(color)
    king_pos = where_king(color)
    opp_color = color == :White ? :Black : :White
    attackers = []
    8.downto(1) do |i|
      1.upto(8) do |j|
        piece = squares[i][j].piece
        #awaryjne debugi
        if piece && piece.color == opp_color
          if king_pos.nil?
            raise "King position is nil!"
          end
          unless piece.pos
            raise "Piece #{piece} at #{i+1},#{j+1} has nil position!"
          end
          if piece.can_move?(king_pos, self)
            attackers << piece
          end
        end
      end
    end
    return [!attackers.empty?, attackers]
  end

  def where_king(color)
    8.downto(1) do |i|
      1.upto(8) do |j|
        piece = squares[i][j].piece
        if piece && piece.color == color && piece.is_a?(King)
          return piece.pos
        end
      end
    end
    return nil
  end

  def get_piece(pos)
    @squares[pos.row][pos.col].piece
  end

  def squares_between(pos1, pos2)
    row_step = (pos2.row <=> pos1.row)
    col_step = (pos2.col <=> pos1.col)

    path = []
    r, c = pos1.row + row_step, pos1.col + col_step
    while [r, c] != [pos2.row, pos2.col]
      path << Position.new(r, c)
      r += row_step
      c += col_step
    end
    return path
  end

  def square_attacked?(pos, color)
    8.downto(1) do |i|
      1.upto(8) do |j|
        piece = @squares[i][j].piece
        next unless piece && piece.color == color
        if piece.is_a?(King)
          return true if (piece.pos.row - pos.row).abs <= 1 && (piece.pos.col - pos.col).abs <= 1
        else
          return true if piece.can_move?(pos, self)
        end
      end
    end
    return false
  end

end

=begin
if __FILE__ == $0
board = Board.new
pos1 = Position.new(1, 7)
pos2 = Position.new(3, 6)
board.draw
puts
board.move(pos1, pos2)
pos1 = Position.new(1, 8)
pos2 = Position.new(1, 7)
board.move(pos1, pos2)
pos1 = Position.new(2, 4)
pos2 = Position.new(4, 4)
board.move(pos1, pos2)
pos1 = Position.new(1, 4)
pos2 = Position.new(4, 4)
board.move(pos1, pos2)
pos1 = Position.new(1, 3)
pos2 = Position.new(3, 5)
board.move(pos1, pos2)
pos1 = Position.new(1, 5)
pos2 = Position.new(2, 5)
board.move(pos1, pos2)
pos1 = Position.new(3, 5)
pos2 = Position.new(4, 4)
board.move(pos1, pos2)
board.draw
end
=end